========================================================================
       NFS String Editor
========================================================================

Version		: 1.05.015 for Windows'98
Date		: 08/25/1999
Author		: Carsten "Gul Orat[TM]" Witte
e-mail		: carsten.witte@gmx.de
Home		: http://www.users.comcity.de/~carsten/efree.htm

========================================================================

Extract this archive to a directory of your choice.

See "NFSStrings.htm" and the context help for details.

========================================================================

Carsten "Gul Orat[TM]" Witte
